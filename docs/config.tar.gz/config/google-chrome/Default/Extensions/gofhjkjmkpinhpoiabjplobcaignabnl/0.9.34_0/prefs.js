// general
prefs('general.version',"0")
prefs('general.firstRun',true)
prefs('general.enabled',true)
prefs('general.silverLight',false)
// display
prefs('display.showInd',0)
prefs('display.indPosition',0)
prefs('display.opacity',0.25)
// page action
prefs('pageAction.enabled',true)
prefs('pageAction.askBeforeHide',true)
// data
prefs('data.whiteList',[{host:"www.youtube.com",enabled:true}])
// options
prefs('options.selectedTab',0)