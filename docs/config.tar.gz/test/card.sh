#!/bin/bash

usage="Usage: card.sh username password cardnumber[cardnumber is for check]~"
agent="Mozilla/7.0 (compatible; MSIE 6.0; Windows NT 5.0)"

datadir=`dirname "$0"`
datadir=`cd "$datadir"; pwd`

timespan=`date +%Y%m%d-%0k%M%S`
cookie=${datadir}/cookie${timespan}.txt
loginfile=${datadir}/login${timespan}.html
recordfile=${datadir}/record${timespan}.html
if [ $# -ne 3 ]; then
	echo $usage
	exit 1
fi

curl -A "${agent}" -o ${loginfile} -D ${cookie} http://kq.neusoft.com/ > /dev/null 2>&1
stat -c %s "${loginfile}" 
while [ $? -ne 0 ]
do
	echo "${timespan} relogin........"
	#random sleep 1---8 seconds
	num=$RANDOM
	let "num %= 8"
	sleep ${num}
	curl -A "${agent}" -o ${loginfile} -D ${cookie} http://kq.neusoft.com/ > /dev/null 2>&1
	stat -c %s "${loginfile}"
done

username=`grep "请输入用户名" ${loginfile} | sed -e "s/^.*name *= *\"//" | sed -e "s/\" *id *= *\".*//"`
password=`grep "请输入密码" ${loginfile} | sed -e "s/^.*name *= *\"//" | sed -e "s/\".*//"`
key=`grep ".*input *type *= *\"text\" *name=\"KEY" ${loginfile} | sed -e "s/^.*input *type *= *\"text\" *name=\"//" | sed -e "s/\".*//"`
neusoft_key=`grep "neusoft_key" ${loginfile} | sed -e "s/^.*neusoft_key.*value *= *\"//" | sed  -e "s/\".*//"`
loginurl=`grep "form action=" ${loginfile} | sed -e "s/^.*form *action *= *\"//" | sed -e "s/\" *method.*//"`

curl -A "${agent}" -s -b ${cookie} http://kq.neusoft.com${loginurl} -d "login=true" -d "neusoft_attendance_online=" -d "${key}=" -d "neusoft_key=${neusoft_key}" -d "${username}=$1" -d "${password}=$2" > /dev/null 2>&1
curl -A "${agent}" -o ${recordfile} -b ${cookie} http://kq.neusoft.com/attendance.jsp > /dev/null 2>&1
currentempoid=`grep ".*input *type *= *\"hidden\" *name=\"currentempoid" ${recordfile} | sed -e "s/^.*value *= *\"//" | sed -e "s/\".*//"`
count1=`grep "$3" ${recordfile} | wc -l`
echo ${currentempoid} ${count1}
# cat ${recordfile}
#random sleep 1---8 seconds
num=$RANDOM
let "num %= 8"
sleep ${num}

curl -A "${agent}" -s -b ${cookie} http://kq.neusoft.com/record.jsp -d "currentempoid=${currentempoid}"> /dev/null 2>&1
curl -A "${agent}" -o ${recordfile} -b ${cookie} http://kq.neusoft.com/attendance.jsp > /dev/null 2>&1
count2=`grep "$3" ${recordfile} | wc -l`
echo ${currentempoid} ${count2}

if [ `expr ${count2} - ${count1}` -ne 1 ];  then
	echo "${timespan} sleep-->${num} ERROR"
	rm -f $cookie $loginfile $recordfile
	exit 1
else
	echo "${timespan} sleep-->${num} OK~~~"
	rm -f $cookie $loginfile $recordfile
	exit 0
fi

