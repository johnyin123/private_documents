#!/bin/bash

cmd="/home/johnyin/test/card.sh tengjh WOzheng\$0 200501010179"

${cmd}

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

