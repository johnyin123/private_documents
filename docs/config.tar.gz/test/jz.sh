#!/bin/bash

cmd="/home/johnyin/test/card.sh jin_zh PengPeng@4 200702017304"

${cmd}

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

