#!/bin/bash
num=$RANDOM
let "num %= 100"
sleep ${num}
