#!/bin/bash


cmd="/home/johnyin/test/card.sh yin.zh passw)rd123 200808026011"

${cmd}

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

if [ $? -ne 0 ]; then
	/home/johnyin/test/sleeprand.sh
	${cmd}
fi

