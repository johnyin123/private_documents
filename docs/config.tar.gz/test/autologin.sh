#!/bin/bash
# ./autologin.sh  "src1844" root@192.168.180.184  df -h

auto_login_ssh ()
{
	expect -c "set timeout -1;
	spawn -noecho ssh -o StrictHostKeyChecking=no $2 ${@:3};
	expect *assword:*;
	send -- $1\r;
	interact;";
}
auto_login_ssh $*
